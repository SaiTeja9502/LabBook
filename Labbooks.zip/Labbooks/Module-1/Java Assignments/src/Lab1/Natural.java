package Lab1;
import java.util.Scanner;
public class Natural
{
public static void main(String[] args)
{
 Scanner sc = new Scanner(System.in);
 System.out.println("Enter a number:");
 int a = sc.nextInt();
 System.out.println(sum.calculateSum(a));
}
}
class sum
{
public  static int calculateSum(int x)
{ 
  int sum=0;
 for(int i=3;i<=x;i++)
 {
  if(i%3==0||i%5==0)
  sum+=1;
 }
 return sum;
}
}
