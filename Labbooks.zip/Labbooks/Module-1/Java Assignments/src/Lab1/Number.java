package Lab1;
import java.util.Scanner;
public class Number
{
public static void main(String[] args)
{
 Scanner sc=new Scanner(System.in);
 int n = sc.nextInt();
 System.out.println(Checknumber.checkNumber(n));
}
}
class Checknumber
{
 public static boolean checkNumber(int n)
{
 int a=n,x=a%10,y;
 while(a!=0)
{
 a=a/10;
 y=a%10;
 if(x>=y)
{
 x=y;
 continue;
}
 else
{
 a=n;
 break;
 }
}
if(a==n)
 return false;
else
 return true;
}
}
