package Lab1;
import java.util.Scanner;
public class Power
{
public static void main(String[] args)
{
 Scanner sc=new Scanner(System.in);
 int n = sc.nextInt();
 System.out.println(Checknumber1.checkNumber(n));
}
}
class Checknumber1
{
 public static boolean checkNumber(int n)
{
 int a=n,pow=2;
 while(pow<=a)
{
 if(pow==a)
 return true;
 else
  pow*=2;
}
return false;
}
}
