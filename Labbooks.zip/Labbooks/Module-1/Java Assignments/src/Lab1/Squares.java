package Lab1;
import java.util.Scanner;
public class Squares
{
 public static void main(String[] args)
{
 Scanner sc= new Scanner(System.in);
 int n = sc.nextInt();
 System.out.println(Difference.calculateDifference(n));
}
}
class Difference
{
 public static int calculateDifference(int a)
{
 int x1=0,x2=0;
 for(int i=1;i<=a;i++)
  x1=x1+(i*i);
 for(int j=1;j<=a;j++)
  x2+=j;
 int x3=x2*x2;
 return Math.abs(x1-x3);
}
}