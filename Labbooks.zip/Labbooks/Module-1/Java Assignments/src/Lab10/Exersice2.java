package Lab10;
import java.util.Scanner;
@FunctionalInterface
interface Test1{
	void spaceWord(String a);
}
public class Exersice2 {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter String:");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		Test1 t=(a)->{
			for(int i=0;i<a.length();i++)
			{
				System.out.print(a.charAt(i)+" ");
			}
		};
		t.spaceWord(s);
	}
}
