package Lab2;
public class Item {

	private int idNo;
	private String title;
	private int noOfCopies;
	public int getIdNo() {
		return idNo;
	}
	public void setIdNo(int idNo) {
		this.idNo = idNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	@Override
	public String toString() {
		return "Item [idNo=" + idNo + ", title=" + title + ", noOfCopies=" + noOfCopies + "]";
	}
}
