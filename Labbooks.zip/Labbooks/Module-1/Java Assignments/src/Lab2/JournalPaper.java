package Lab2;

public class JournalPaper extends WrittenItem{

	private int dateOfRelease;

	public int getDateOfRelease() {
		return dateOfRelease;
	}
	public void setDateOfRelease(int dateOfRelease) {
		this.dateOfRelease = dateOfRelease;
	}
	@Override
	public String toString() {
		return "JournalPaper [dateOfRelease=" + dateOfRelease + "]";
	}
}
