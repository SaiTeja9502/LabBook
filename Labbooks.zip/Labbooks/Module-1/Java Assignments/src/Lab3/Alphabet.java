package Lab3;
import java.util.Scanner;
public class Alphabet
{
public static void main(String[] args)
{
 Scanner sc = new Scanner(System.in);
 System.out.print("Enter the number of elemenets:");
 int n = sc.nextInt();
 String[] s = new String[n];
 for(int i=0;i<s.length;i++)
 s[i]=sc.next();
 Sort.sortInAlphabeticalOrder(s);
}
}
class Sort
{
 public static void sortInAlphabeticalOrder(String[] s)
{
  int a,b;String n,m;
  for(int i=0;i<s.length;i++)
  {
     for(int j=i+1;j<s.length;j++)
     { 
       a=s[i].charAt(0);
       b=s[j].charAt(0);
       if(a>b)
       {
        n=s[j];
        s[j]=s[i];
        s[i]=n;
       }
     }
  }
  if((s.length)/2==0)
  {
  for(int i=0;i<(s.length/2);i++)
  { 
   m = s[i].toUpperCase();
   s[i]= m;
  }
  for(int i=(s.length)/2;i<s.length;i++)
  { 
   m = s[i].toLowerCase();
   s[i]= m;
  }
  }
 else
  {
  for(int i=0;i<(s.length/2)+1;i++)
  { 
   m = s[i].toUpperCase();
   s[i]= m;
  }
  for(int i=(s.length)/2+1;i<s.length;i++)
  { 
   m = s[i].toLowerCase();
   s[i]= m;
  }
  }
for(int i=0;i<s.length;i++)
 System.out.println(s[i]);
}
}