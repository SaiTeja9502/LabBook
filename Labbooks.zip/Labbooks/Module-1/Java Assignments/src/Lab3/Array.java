package Lab3;
import java.util.Scanner;
public class Array
{
 public static void main(String[] args)
{
 Scanner sc= new Scanner(System.in);
 System.out.print("Enter the number of elements : ");
 int n = sc.nextInt();
 int[] a= new int[n];
 for(int i=0;i<n;i++)
  a[i]=sc.nextInt();
 System.out.print("The second smallest numberr in the array is : "+Get.getSecondSmallest(a));
}
}
class Get
{
 public static int getSecondSmallest(int[] a)
{
 int l=0;
 for(int i=0;i<a.length;i++)
{
 for(int j=i;j<a.length;j++)
 {  
  if(a[j]<a[i])
  {
   l=a[j];
   a[j]=a[i];
   a[i]=l;
  }
 }
}
return a[1];
}
}