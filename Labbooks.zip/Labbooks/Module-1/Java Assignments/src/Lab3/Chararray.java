package Lab3;
import java.util.Scanner;
public class Chararray
{
 public static void main(String[] args)
{
 Scanner sc = new Scanner(System.in);
 System.out.println("Enter the number of elements:");
 int n = sc.nextInt();
 char[] a  = new char[n];
 String b;
 System.out.println("Enter the characters:");
 for(int i=0;i<n;i++)
{
  b = sc.next();
  a[i] = b.charAt(0);
}
  Number.charCount(a);
} 
}
class Number
{
 public static void charCount(char[] a)
{
int count=0;
byte b = 0;
 for(int i=0;i<a.length;i++)
{
 b=0;
 for(int k=i-1;k>=0;k--)
   if(a[i]==a[k])
   {
    b = 1;
    break;
   }
 if(b !=1)
 {
  for(int j=0;j<a.length;j++)
  { 
  
   if(a[i]==a[j])
   count++;
  }
  System.out.println("The number of times "+a[i]+" is present int the array "+count);
  count=0;
 }
}
}
}