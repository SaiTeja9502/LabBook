package Lab3;
import java.util.Scanner;
public class ReverseOfArray
{
 public static void main(String[] args)
{
 Scanner sc= new Scanner(System.in);
 System.out.print("Enter the number of elements:");
 int n = sc.nextInt();
 int[] a = new int[n];
 for(int i=0;i<n;i++)
 a[i] = sc.nextInt();
 Sorting.getSorted(a,n);
System.out.print("Sorted elements are:");
for(int i=0;i<n;i++)
 System.out.println(a[i]);
}
}
class Sorting
{
 public static int[] getSorted(int[] a,int n)
{
int b=0;
for(int i=n-1;i>0;i--)
{
 b = a[n-i-1];
 a[n-i-1] = a[i];
 a[i]=b;
}
System.out.print("Reversed elements are:");
for(int i=0;i<n;i++)
 System.out.println(a[i]);
for(int i=0;i<a.length;i++)
for(int j=i+1;j<a.length;j++)
  if(a[i]>a[j])
  {
    b = a[i];
   a[i] = a[j];
   a[j]=b;
  }
return a;
}
}