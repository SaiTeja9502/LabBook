package Lab4;
import java.util.Scanner;
public class Cube
{
 public static void main(String[] args)
{
 Scanner sc = new Scanner(System.in);
 int n = sc.nextInt();
 System.out.println(Ad.cubeOfANumber(n));
}
}
class Ad
{
public static int cubeOfANumber(int a)
{
int sum=0,n;
while(a!=0)
{
n=a%10;
sum=sum+(n*n*n);
a=a/10;
}
return sum;
}
}