package Lab5;

import java.util.Scanner;

@SuppressWarnings("serial")
class AgeException extends Throwable{
	public AgeException(String errorMsg){		
			super(errorMsg);
	}
}

public class Exercise5 {
	
	static void validation(int age) throws  AgeException
	{
		if(age<15)
			throw new AgeException("Enter valid age");	
		else		
		   System.out.println("Valid Age");
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) throws AgeException {
		Scanner sc=new Scanner(System.in);
		int age=sc.nextInt();
		Exercise5.validation(age);
	}
}
