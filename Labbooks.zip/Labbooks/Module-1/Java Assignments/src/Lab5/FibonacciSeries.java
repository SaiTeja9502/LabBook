package Lab5;
import java.util.Scanner;
public class FibonacciSeries 
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
    System.out.println("Enter a number to find fibonacci series ");
    int n = sc.nextInt();
    System.out.println("The fibonacci series of "+n+"th number is "+fibonacciFinder(n));  
}
public static int fibonacciFinder(int n)
{
	int a=1,b=1,c=2,d=0;
	if(n==1||n==2)
		return n;
	else
	{
		while(c<n)
		{
			d=a;
			a=b;
			b=a+d;
			c++;
		}
		return a+b;
	}
}
}