package Lab5;
import java.util.Scanner;
public class PrimeNumber 
{
public static void main(String[] args)
{
   Scanner sc = new Scanner(System.in);
   System.out.println("Enter a number to print prime number upto that number");
   int n = sc.nextInt();
   primeNumberPrinter(n);
}
public static void primeNumberPrinter(int n)
{
	int b=3,a=0;
	System.out.print("2 ");
	while(b<=n)
	{
		for(int i=2;i<b;i++)
		{
			if(b%i==0)
				a++;
		}
		if(a==0)
			System.out.print(b+" ");
		b++;
		a=0;
	}
}
}
