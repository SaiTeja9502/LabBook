package Lab5;
import java.util.Scanner;
public class TrafficLights
{
 public static void main(String[] args)
 {
   int enteredOption;
   Scanner sc = new Scanner(System.in);
   System.out.println("Select the following options:");
   System.out.println("1. Red");
   System.out.println("2. Yellow");
   System.out.println("3. Green");
   enteredOption = sc.nextInt();
   switch(enteredOption)
   {
     case 1:
        System.out.println("Stop");
        break;
     case 2:
        System.out.println("Ready");
        break;
     case 3:
        System.out.println("Go");
        break;
     default:
        System.out.println("Invalid option");
         break;
   }
 }
}