package Lab6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Exercise2 {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		
		String file="fileverify.txt";
		 FileReader f=new FileReader(file);
		 BufferedReader bufffile=new BufferedReader(f);
		 int j=0;
		 String line=null;
		 while((line=bufffile.readLine())!=null)
		 {
			 j=j+1;
			 System.out.println(j+" "+line);
		 }
		 
	}
}
