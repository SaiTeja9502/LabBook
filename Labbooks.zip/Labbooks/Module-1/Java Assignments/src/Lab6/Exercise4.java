package Lab6;

import java.util.Scanner;

public class Exercise4 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner sc=new Scanner(System.in);
		String data=sc.next();
		Exercise4 e=new Exercise4();
		System.out.println(e.alterString(data));
	}

String  alterString(String data) {
	StringBuffer alterdata=new StringBuffer();
	char[] c=data.toCharArray();
	for(int i=0;i<data.length();i++)
	{
		if(c[i]>='a' && c[i]<='z' || c[i]>='A' &&  c[i]<='Z')
			if(!(c[i]=='a' || c[i]=='e' || c[i]=='i' || c[i]=='o' || c[i]=='u'||c[i]=='A' || c[i]=='E' || c[i]=='I' || c[i]=='O' || c[i]=='U'))
			{
				c[i]=(char) (c[i]+1);
			}
		
		alterdata.insert(i, c[i]);
	}
	String dataresult=alterdata.toString();
	return dataresult;
	}

}
