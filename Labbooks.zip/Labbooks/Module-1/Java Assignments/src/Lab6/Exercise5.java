package Lab6;

import java.util.Scanner;

public class Exercise5 {
	void modifyNumber(String snum)
	{
	
	StringBuffer sdiff=new StringBuffer(snum.length());
	int j=0;
	for(int i=0;i<snum.length()-1;i++,j++)
	{
		int a=snum.charAt(i);
		int b=snum.charAt(i+1);
		sdiff.insert(j,Math.abs(b-a));	
	}
	if(snum.length()%2 == 0)
		System.out.println(sdiff);
	else
		System.out.println(sdiff+""+snum.charAt(snum.length()-1));
	}
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Integer");
		Integer num=sc.nextInt();
		String snum=num.toString();
		Exercise5 e=new Exercise5();
		e.modifyNumber(snum);
	}
}
