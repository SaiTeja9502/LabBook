package Lab6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Exercise6 {

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("Enter the file name  WITH EXTENSION ");
		Scanner sc=new Scanner(System.in);
		String filename=sc.next();
		FileReader f=new FileReader(filename);
		BufferedReader fbuff=new BufferedReader(f);
		int lineCount=0;
		int spaceCount=0;
		int letterCount=0;
		String line=null;
			try {
				while((line=fbuff.readLine())!=null)
				{
						letterCount+=line.length();
						lineCount++;
						for(int i=0;i<line.length();i++)
						{
						if(line.charAt(i) == ' '){
							spaceCount++;
						}
						}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		System.out.println("Words "+(letterCount-spaceCount-lineCount));
		System.out.println("Characters "+letterCount);
		System.out.println("Lines "+lineCount);
		
	}
}
