package Lab6;

import java.io.File;
import java.util.Scanner;

public class Exercise7 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
	
		System.out.println("Enter filename with extension");
		Scanner sc=new Scanner(System.in);
		String file=sc.next();
		File f=new File(file);
		boolean verify;
		verify=f.exists();
		
		if(verify==true)
			System.out.println("File Exists");
		else 
			System.out.println("File Doesn't Exists");
		
		verify=f.canRead();
		
		if(verify ==true)
			System.out.println("File is readable");
		else 
			System.out.println("File is not readable");
		
		verify=f.canWrite();
		
		if(verify==true)
			System.out.println("File is writable");
		else 
			System.out.println("File Doesn't Exists");
		
		System.out.println("Length "+f.length()+" bytes");
	}
}
