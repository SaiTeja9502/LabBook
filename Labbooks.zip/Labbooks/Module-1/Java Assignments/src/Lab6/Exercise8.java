package Lab6;

import java.util.Scanner;

public class Exercise8 {

	public static void main(String[] args) {
		System.out.println("Enter a Word");
		Scanner sc=new Scanner(System.in);
		String word=sc.next();
		Exercise8 e=new Exercise8();
		if(e.type(word))
			System.out.println("Type is positive");
		else 
			System.out.println("Type is Negative");
		
	}

	 boolean type(String word) {
		 int count=1;
		 
		 for(int i=0;i<word.length()-1;i++)
		 {
			if(word.charAt(i)<word.charAt(i+1))
					count++;
			else
				count--;
		 }
		 if(count==word.length())
			 	return true;
		 else 
			 return false;
	 }
}
