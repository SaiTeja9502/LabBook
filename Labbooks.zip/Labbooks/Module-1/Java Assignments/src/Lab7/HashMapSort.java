package Lab7;
//import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
//import java.util.Comparator;
import java.util.HashMap;
//import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.Set;
//import java.util.TreeMap;
import java.util.Collection;
public  class HashMapSort {
	public List getValues(HashMap hm)
	{
		Set ks=hm.keySet();//return all keys	
		Collection v1=hm.values();
	System.out.println(ks);
	System.out.println(v1);
		Object o[]=v1.toArray();
		 Arrays.sort(o);
		 List l=Arrays.asList(o);
		return l;	
	}
	public static void main(String[] args) {
	//List<Integer> a=new Vector<Integer>();
	HashMap<Integer,Object> hm=new HashMap<Integer,Object>();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter keys & values:");
	for(int i=0;i<5;i++)
	{
		int key=sc.nextInt();
		String value=sc.next();
		hm.put(key, value);
	}
	System.out.println(hm);
	HashMapSort h=new HashMapSort();
	List l=h.getValues(hm);
	 System.out.println(l);
	}
	}
