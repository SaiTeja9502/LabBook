package Lab7;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class ReverseSortArray
{
int[] getSorted(int[] a)
{
int[] b=new int[a.length];
for(int i=0;i<a.length;i++)
{
String a1=Integer.toString(a[i]);
StringBuffer ab=new StringBuffer(a1);
b[i]=Integer.parseInt(ab.reverse().toString());
}
List<Integer> list=new ArrayList<Integer>();
for(int i=0;i<a.length;i++)
{
list.add(b[i]);//adding array elements into list
}
Collections.sort(list);//sorting using collections class
int[] arr=new int[a.length];
for(int i=0;i<a.length;i++)
{
arr[i]=list.get(i);//getting list elements into array
}
return arr;
}
public static void main(String[] args) {
RevSortArray d=new RevSortArray();
int[] a=new int[5];
Scanner sc=new Scanner(System.in);
for(int i=0;i<a.length;i++)
{
a[i]=sc.nextInt();
}
int[] arr=d.getSorted(a);
System.out.println(Arrays.toString(arr));
}
}