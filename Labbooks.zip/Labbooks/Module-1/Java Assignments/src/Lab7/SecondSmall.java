package Lab7;
import java.io.*;
import java.util.*;
public class SecondSmall {
		public int getSecondSmallest(int[]a){
			ArrayList<Integer> list = new ArrayList<>(a.length);
			for (int i : a) {
				list.add(Integer.valueOf(i));
			}
			Collections.sort(list);
			System.out.println(list);
			return list.get(1);	
		}
		public static void main(String[] args) {
			int a[]=new int[6];
			Scanner sc=new Scanner(System.in);
			System.out.println("enter any "+ a.length + " integers");
		for(int i=0;i<a.length;i++)
			a[i]=sc.nextInt();
		SecondSmall e=new SecondSmall();
		System.out.println("the second smallest in the arraylist is:"+e.getSecondSmallest(a));				 
		}}