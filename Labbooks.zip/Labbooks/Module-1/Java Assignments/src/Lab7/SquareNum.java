package Lab7;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
public class SquareNum {
		Map<Integer,Integer> getSquares(int[] a)
		{
		int[] b=new int[a.length];
		Map<Integer,Integer> m=new HashMap<Integer,Integer>();
		for(int i=0;i<a.length;i++)
		{
		b[i]=a[i]*a[i];
		m.put(a[i],b[i]);
		}
		return m;
		}
		public static void main(String[] args) {
		SquareNum d=new SquareNum();
		Scanner sc=new Scanner(System.in);
		int[] a=new int[5];
		for(int i=0;i<a.length;i++)
		{
		a[i]=sc.nextInt();
		}
		System.out.println(d.getSquares(a));
		}
		}
