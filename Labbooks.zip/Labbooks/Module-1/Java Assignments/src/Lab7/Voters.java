package Lab7;
import java.util.*;
import java.util.Map.Entry;
public class Voters {
List<Integer> votersList (Map hm)
{
Set s=hm.entrySet();
List<Integer> l=new ArrayList<Integer>();
Iterator i=s.iterator();
while(i.hasNext())
{
Map.Entry me=(Map.Entry)i.next();
//System.out.println((Integer)me.getKey());
if((Integer)me.getValue()>18)
{
l.add((Integer)me.getKey());
}
}
return l;
}
public static void main(String[] args) {
Voters d=new Voters();
System.out.println("Enter the id and age of people:");
Scanner sc=new Scanner(System.in);
Map<Integer,Integer> hm=new HashMap<Integer,Integer>();
for(int i=0;i<5;i++)
{
int key=sc.nextInt();
int value=sc.nextInt();
hm.put(key, value);
}
System.out.println("the id list of eligible voters are"+d.votersList(hm));
}
}
